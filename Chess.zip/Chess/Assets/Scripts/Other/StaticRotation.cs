﻿using UnityEngine;
using System.Collections;

public class StaticRotation : MonoBehaviour {
	void Update () {
		transform.eulerAngles = new Vector3(0, CameraController.eulerAngles.y - 45, 0);
	}
}
