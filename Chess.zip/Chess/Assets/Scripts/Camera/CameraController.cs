﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

	private Vector2 start;
	private Vector2 end;
	private float speed;
	private bool moving;

	public static Vector3 eulerAngles;
	
	void Update () {
		eulerAngles = transform.eulerAngles; 
	}
}
