﻿using UnityEngine;
using System.Collections;

public class Transparent : MonoBehaviour {

	public float alpha;
	private Color c;

	void Start() {
		c = GetComponent<Renderer> ().material.color;
	}

	void Update () {
		GetComponent<Renderer> ().material.color = new Vector4 (c.r, c.g, c.b, alpha);
	}
}
