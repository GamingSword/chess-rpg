﻿using UnityEngine;
using System.Collections;

public class Piece : MonoBehaviour {
	private float health;
	private float damage;
}
